extends Control

# ==============================================================
# VARIÁVEIS EXPORTADAS — configure no Inspector de cada card
# ==============================================================
@export var phase_id      : String    = "1_1"
@export var phase_texture : Texture2D
@export var unlock_sound  : AudioStream

# ==============================================================
# ESTADO INTERNO
# ==============================================================
var is_unlocked  : bool = false
var is_animating : bool = false
var is_hovering  : bool = false
var mat          : ShaderMaterial

# ==============================================================
# REFERÊNCIAS DE NÓS
# Nomes conforme sua card_phase.tscn atual:
#   CardButton / CardImage / LockOverlay / GrayOverlay /
#   AnimPlayer / UnlockSound / StarParticles
# ==============================================================
@onready var card_btn  : TextureButton     = $CardButton
@onready var card_img  : TextureRect       = $CardButton/CardImage
@onready var lock_icon : TextureRect       = $CardButton/CardImage/LockOverlay
@onready var flash     : ColorRect         = $GrayOverlay
@onready var sfx       : AudioStreamPlayer = $UnlockSound
@onready var stars     : GPUParticles2D    = $StarParticles

signal card_pressed(phase_id: String)

# ==============================================================
# INICIALIZAÇÃO
# ==============================================================
func _ready() -> void:
	# Aplica textura do card
	if phase_texture:
		card_img.texture = phase_texture

	# Carrega e aplica o shader — caminho adaptado à sua pasta Shaders/
	var shader_mat := ShaderMaterial.new()
	shader_mat.shader = load("res://Menu Principal/Shaders/gray_card.gdshader")
	card_img.material = shader_mat
	mat = shader_mat

	# Som de desbloqueio
	if unlock_sound:
		sfx.stream = unlock_sound

	# Conecta o botão
	card_btn.pressed.connect(_on_pressed)

	# Consulta o ProgressManager e aplica estado inicial SEM animação
	is_unlocked = ProgressManager.is_unlocked(phase_id)
	if is_unlocked:
		_apply_unlocked_appearance()
	else:
		_apply_locked_appearance()

# ==============================================================
# HOVER (zoom suave apenas quando desbloqueado)
# ==============================================================
func _process(_delta: float) -> void:
	if is_animating: return
	var hovered := card_btn.is_hovered()
	if hovered and not is_hovering:
		is_hovering = true
		_handle_zoom(1.08)
	elif not hovered and is_hovering:
		is_hovering = false
		_handle_zoom(1.0)

func _handle_zoom(target: float) -> void:
	if not is_unlocked: return
	z_index = 10 if target > 1.0 else 0
	create_tween()\
		.set_ease(Tween.EASE_OUT)\
		.set_trans(Tween.TRANS_QUAD)\
		.tween_property(self, "scale", Vector2(target, target), 0.1)

# ==============================================================
# ESTADOS VISUAIS
# ==============================================================
func _apply_locked_appearance() -> void:
	card_btn.disabled = true
	lock_icon.visible = true
	if mat:
		mat.set_shader_parameter("gray_amount", 1.0)
		mat.set_shader_parameter("brightness",  0.3)

func _apply_unlocked_appearance() -> void:
	card_btn.disabled = false
	lock_icon.visible = false
	if mat:
		mat.set_shader_parameter("gray_amount", 0.0)
		mat.set_shader_parameter("brightness",  1.0)

# ==============================================================
# API PÚBLICA — chamada pelo MenuPrincipal.gd
# ==============================================================
func unlock(animate: bool = true) -> void:
	if is_unlocked: return
	is_unlocked = true
	if animate:
		_play_unlock_animation()
	else:
		_apply_unlocked_appearance()

# ==============================================================
# ANIMAÇÃO DE DESBLOQUEIO
# ==============================================================
func _play_unlock_animation() -> void:
	is_animating = true
	if sfx.stream: sfx.play()

	# Flash branco inicial
	flash.color   = Color(1, 1, 1, 0.8)
	flash.visible = true

	var t := create_tween()

	# Etapa 1 — flash + escala simultâneos
	t.set_parallel(true)
	t.tween_property(flash, "color:a", 0.0, 0.35)
	t.tween_property(self, "scale", Vector2(1.22, 1.22), 0.18)\
	 .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

	# Etapa 2 — volta escala + desgrayifica simultaneamente
	t.set_parallel(false)
	t.tween_property(self, "scale", Vector2(1.0, 1.0), 0.22)\
	 .set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

	t.set_parallel(true)
	if mat:
		t.tween_method(
			func(v): mat.set_shader_parameter("gray_amount", v),
			1.0, 0.0, 0.5)
		t.tween_method(
			func(v): mat.set_shader_parameter("brightness", v),
			0.3, 1.0, 0.5)

	# Etapa 3 — finaliza: partículas + shimmer
	t.set_parallel(false)
	t.tween_callback(func():
		_apply_unlocked_appearance()
		flash.visible = false
		is_animating  = false
		_fire_stars()
		_play_shimmer_effect()
	)

# ==============================================================
# PARTÍCULAS DE ESTRELAS
# ==============================================================
func _fire_stars() -> void:
	stars.emitting = false
	await get_tree().process_frame
	stars.emitting = true

# ==============================================================
# SHIMMER DIAGONAL
# ==============================================================
func _play_shimmer_effect() -> void:
	var shimmer := ColorRect.new()
	shimmer.color    = Color(1, 1, 1, 0.30)
	shimmer.size     = Vector2(40, 220)
	shimmer.rotation = deg_to_rad(22)
	shimmer.position = Vector2(-60, -20)
	add_child(shimmer)

	var t := create_tween()
	t.tween_property(shimmer, "position:x", 220.0, 0.45)\
	 .set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	t.tween_callback(shimmer.queue_free)

# ==============================================================
# CLIQUE NO CARD
# ==============================================================
func _on_pressed() -> void:
	if is_unlocked and not is_animating:
		emit_signal("card_pressed", phase_id)
