extends Node

# Sinal emitido quando uma fase é desbloqueada
# O MenuPrincipal escuta este sinal para disparar a animação
signal phase_unlocked(id: String)

# Mapa de dependências: completar X desbloqueia Y
const UNLOCK_MAP : Dictionary = {
	"1_1": "1_2",
	"1_2": "1_3",
	# Adicione mais fases aqui conforme o jogo crescer:
	# "1_3": "2_1",
}

# ==============================================================
# CONSULTAS
# ==============================================================
func is_unlocked(id: String) -> bool:
	return id in SaveManager.get_unlocked()

func is_completed(id: String) -> bool:
	return id in SaveManager.get_completed()

# ==============================================================
# AÇÕES
# ==============================================================

# Chame isto ao final de cada fase jogada
func complete_phase(id: String) -> void:
	if not is_unlocked(id):
		push_warning("[ProgressManager] Tentou completar fase bloqueada: " + id)
		return

	SaveManager.complete_phase(id)  # persiste em disco

	# Verifica se desbloqueia próxima fase
	if id in UNLOCK_MAP:
		var next : String = UNLOCK_MAP[id]
		if not is_unlocked(next):
			SaveManager.unlock_phase(next)      # persiste em disco
			emit_signal("phase_unlocked", next) # dispara animação no mapa

func get_all_unlocked() -> Array:
	return SaveManager.get_unlocked()
