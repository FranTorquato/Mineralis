extends Node2D

# ==============================================================
# REFERÊNCIAS DOS CARDS
# Nomes conforme sua cena MenuPrincipal.tscn
# ==============================================================
@onready var cards : Dictionary = {
	"1_1": $Card_1_1,
	"1_2": $Card_1_2,
	"1_3": $Card_1_3,
}

# ==============================================================
# INICIALIZAÇÃO
# ==============================================================
func _ready() -> void:
	await get_tree().process_frame  # garante que os cards carregaram

	_setup_cards()

	# Escuta o sinal do ProgressManager para animar desbloqueios em tempo real
	ProgressManager.phase_unlocked.connect(_on_phase_unlocked)

func _setup_cards() -> void:
	for id in cards:
		var card = cards[id]
		if card == null: continue

		# Restaura estado salvo SEM animação
		if ProgressManager.is_unlocked(id):
			card.unlock(false)

		# Conecta clique do card
		if not card.card_pressed.is_connected(_on_card_selected):
			card.card_pressed.connect(_on_card_selected)

# ==============================================================
# DESBLOQUEIO EM TEMPO REAL (vindo do ProgressManager)
# ==============================================================
func _on_phase_unlocked(id: String) -> void:
	if cards.has(id):
		cards[id].unlock(true)   # COM animação

# ==============================================================
# CLIQUE NO CARD — navega para a fase
# ==============================================================
func _on_card_selected(id: String) -> void:
	print("[MenuPrincipal] Navegando para fase: ", id)
	# Ajuste o caminho conforme sua estrutura de pastas:
	get_tree().change_scene_to_file("res://Fase %s/fase_%s.tscn" % [id.replace("_", "-"), id])

# ==============================================================
# TECLAS DE TESTE — REMOVER ANTES DO BUILD FINAL
# ==============================================================
func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed): return

	match event.keycode:
		KEY_1:
			# Simula conclusão da fase 1_1 → desbloqueia 1_2 com animação
			print("[TESTE] Completando fase 1_1...")
			ProgressManager.complete_phase("1_1")
		KEY_2:
			# Simula conclusão da fase 1_2 → desbloqueia 1_3 com animação
			print("[TESTE] Completando fase 1_2...")
			ProgressManager.complete_phase("1_2")
		KEY_R:
			# Reseta todo o progresso e recarrega a cena
			print("[TESTE] Resetando save...")
			SaveManager.reset_save()
			get_tree().reload_current_scene()
		KEY_U:
			# Força unlock direto com animação (debug emergencial)
			print("[TESTE] Forçando unlock do Card_1_2...")
			var c = cards.get("1_2")
			if c:
				c.is_unlocked = false
				c.unlock(true)
